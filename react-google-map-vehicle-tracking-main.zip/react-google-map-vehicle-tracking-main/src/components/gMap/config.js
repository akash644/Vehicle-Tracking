const config = {
    mapsKey: 'AIzaSyA5Lt3E5gYb-lfogvaSpCrvCpocLqHwNOI',
    myMapyKey: 'AIzaSyD3Z_edB-m-oe6KSruM2GkNUODtXU7bEo8',
}

export default config;

